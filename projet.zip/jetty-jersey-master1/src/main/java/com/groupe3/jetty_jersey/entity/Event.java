package com.groupe3.jetty_jersey.entity;

import java.util.Date;

public class Event {
	private int eventId;
	private String name;
	private double X, Y;
	private String place;
	private String picture;
	private Date startDate, endingDate;
	private Map map;

	public Event() {
		// TODO Auto-generated constructor stub
	}

	public Event(int eventId, String name, double x, double y, String place, String picture, Date startDate,
			Date endingDate, Map map) {
		super();
		this.eventId = eventId;
		this.name = name;
		X = x;
		Y = y;
		this.place = place;
		this.picture = picture;
		this.startDate = startDate;
		this.endingDate = endingDate;
		this.map = map;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getX() {
		return X;
	}

	public void setX(double x) {
		X = x;
	}

	public double getY() {
		return Y;
	}

	public void setY(double y) {
		Y = y;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndingDate() {
		return endingDate;
	}

	public void setEndingDate(Date endingDate) {
		this.endingDate = endingDate;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

}
