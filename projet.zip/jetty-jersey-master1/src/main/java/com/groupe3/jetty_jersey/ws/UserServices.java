package com.groupe3.jetty_jersey.ws;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/user")
public class UserServices {
	
	public static class ExampleClass {
		public String field;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/login")
	public ExampleClass getConnected(@FormParam("username") String userName, @FormParam("pwd") String userPwd) {
		ExampleClass instance = new ExampleClass();
		instance.field="Hello "+userName+" your password is "+userPwd;
		return instance;
	}
	
//	@GET
//	@Produces(MediaType.APPLICATION_JSON)
//	@Path("/login")
//	public String getRegistered(@FormParam("username") String userName, @FormParam("pwd") String userPwd) {
//		System.out.println(userName + "=======" + userPwd);
//		if (userName == null || userPwd == null) {
//			String json = "{\"result\":\"error\"}";
//			System.out.println(json);
//			return json;
//		} else {
//			String testR = "{\"result\":\"account & password correct :(\"}";
//			return testR;
//		}
//	}
}