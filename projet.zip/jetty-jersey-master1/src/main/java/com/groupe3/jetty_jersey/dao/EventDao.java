package com.groupe3.jetty_jersey.dao;

import java.util.List;

import com.groupe3.jetty_jersey.entity.Event;
import com.groupe3.jetty_jersey.entity.Map;


public interface EventDao {
	
	void createEvent(Map map, Event event);
	void deleteEvent(Event event);
	
	List<Event> eventsByMap(Map map);
	List<Event> eventsByCategory(String category);
	
	List<Event> allEvents();
	


}
