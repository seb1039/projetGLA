package com.groupe3.jetty_jersey.entity;

public class Map {
	private int mapId;
	private int mapName;
	private String mapCategory;
	public Map() {
		// TODO Auto-generated constructor stub
	}
	public Map(int mapId, int mapName, String mapCategory) {
		super();
		this.mapId = mapId;
		this.mapName = mapName;
		this.mapCategory = mapCategory;
	}
	public int getMapId() {
		return mapId;
	}
	public void setMapId(int mapId) {
		this.mapId = mapId;
	}
	public int getMapName() {
		return mapName;
	}
	public void setMapName(int mapName) {
		this.mapName = mapName;
	}
	public String getMapCategory() {
		return mapCategory;
	}
	public void setMapCategory(String mapCategory) {
		this.mapCategory = mapCategory;
	}
	
}
