package com.groupe3.jetty_jersey.ws;

public class MapServices {

	public MapServices() {
		// TODO Auto-generated constructor stub
	}

}
