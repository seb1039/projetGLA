package com.groupe3.jetty_jersey.dao;

import java.util.List;

import com.groupe3.jetty_jersey.entity.Map;

public interface MapDao {

	void createMap(String name,String category);
	void createCategory(String category);
	void deleteMap(Map map);
	void deleteCategory(String category);
	
	void modifyCategory(String mapName,String category);
	void modifyName(String oldName,String newName);
	
	Map searchByName (String name);
	
	List<Map> searchByCategory(String category);
	List<Map> getMaps();
	
	
}
