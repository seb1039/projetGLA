package com.groupe3.jetty_jersey.dao;

import java.util.List;

import com.groupe3.jetty_jersey.entity.User;


public interface UserDao {

	void createUser(User user);
	void modifyUser(User user);
	void deleteUser(User user);
	
	User getUser(String username);
	
	List<User> getUsers();
	List<User> searchByName(String name);
	List<User> searchByMail(String mail);
	
	
	
}
