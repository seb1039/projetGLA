package com.groupe3.jetty_jersey.entity;

import java.util.Date;

public class User {
	private int userId;
	private String userName;
	private String userPwd;
	private Date userBirthDate;
	private String userEmail;
	private String userLastName;
	private String userFirstName;
	private String userGender;

	public User() {

	}

	public User(int userId, String userName, String userPwd, Date userBirthDate, String userEmail, String userLastName,
			String userFirstName, String userGender) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userPwd = userPwd;
		this.userBirthDate = userBirthDate;
		this.userEmail = userEmail;
		this.userLastName = userLastName;
		this.userFirstName = userFirstName;
		this.userGender = userGender;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserPwd() {
		return userPwd;
	}

	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}

	public Date getUserBirthDate() {
		return userBirthDate;
	}

	public void setUserBirthDate(Date userBirthDate) {
		this.userBirthDate = userBirthDate;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

}
