package com.group3.jetty_jersey.ws;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.group3.jetty_jersey.dao.MapDao;

@Path("/map")
public class MapService {
	MapDao mapDao = new MapDao();

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/delete/{id_map}")
	public String deleteMap(@PathParam("id_map") String id) {
		try {
			mapDao.delete(id);
			return "{\"result\":\"success\"}";
		} catch (Exception e) {
			return "{\"result\":\"error\"}";
		}
	}

	/*@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/modify/{id_map}")
	public String modifyMap(@PathParam("id_map") String id, String attribut, String valeur) {
		try {
			mapDao.update(id, attribut, valeur);
			return "{\"result\":\"success\"}";
		} catch (Exception e) {
			return "{\"result\":\"error\"}";
		}
	}*/

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/info/{id_map}")
	public String infoCarte(@PathParam("id_map") String id) throws Exception {
		return mapDao.getByID(id);
	}
}
