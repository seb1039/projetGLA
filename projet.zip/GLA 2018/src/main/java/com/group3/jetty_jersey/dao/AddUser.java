package com.group3.jetty_jersey.dao;

import com.group3.jetty_jersey.entity.User;

public class AddUser {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserDao userDao = new UserDao();
		// User user = new User("mcc0", "Gilles dOr", "lolo@lolo.com");
		String date = "1999,11,11";
		// date.setYear(1999);date.setMonth(10);
		for (int i = 0; i < 10; i++) {
			User user = new User("Brydoup", "14598h", date, "mail@mil.fr", "dar", "ha", "m");

			try {
				// String username = user.getUser_name();
				String result = userDao.add(user);
				Thread.sleep(1000);
				if (result.equals("OK")) {
					System.out.println("update success");
				} else if (result.equals("CREATED")) {
					System.out.println("add success");
				}
				Thread.sleep(1000);
				System.out.println("fin=============================");
			} catch (Exception e) {
				e.toString();
			}
		}
	}
}
