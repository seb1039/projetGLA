package com.group3.jetty_jersey.ws;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.group3.jetty_jersey.dao.UserDao;
import com.group3.jetty_jersey.entity.User;

@Path("/user")
public class UserService {
	// objet user dao
	private UserDao userDao = new UserDao();
	@Context
	HttpServletRequest request;

	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes("application/x-www-form-urlencoded")
	@Path("/new")
	public String creerUtilisateur(@FormParam("nom") String nom, @FormParam("pwd") String pwd,
			@FormParam("date") String daten, @FormParam("mail") String mail, @FormParam("last") String last,
			@FormParam("first") String first, @FormParam("gender") String gender) {
		@SuppressWarnings("deprecation")
		String date = daten;

		User user = new User(nom, pwd, date, mail, last, first, gender);

		System.out.println(user);

		try {
			String result = userDao.add(user);
			Thread.sleep(1000);
			if (result.equals("OK")) {
				return "{\"result\":\"success\"}";
			} else if (result.equals("CREATED")) {
				return "{\"result\":\"success\"}";
			}

			Thread.sleep(1000);

			System.out.println("fin=============================");
		} catch (Exception e) {
			
		}
		return "{\"result\":\"echec\"}";
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes("application/x-www-form-urlencoded")
	@Path("/login")
	public String login(@FormParam("id") String userId, @FormParam("pwd") String userPwd) throws Exception {
		System.out.println(userId + "=======" + userPwd);
		if (userId == null || userPwd == null) {
			return "{\"result\":\"empty fields\"}";
		} else {
			String userResult = userDao.getByID(userId);
			if (userResult == null) {
				return "{\"result\":\"account or password incorrect :(\"}";
			}
			System.out.println(userResult);
			ObjectMapper mapper = new ObjectMapper();
			User user = mapper.readValue(userResult, User.class);
			if (user.getPassword().equals(userPwd)) {
				request.getSession().setAttribute("userId", user.getId_user());
				return "{\"result\":\"success\"}";
			} else {
				return "{\"result\":\"account or password incorrect :(\"}";
			}
		}

	}
}