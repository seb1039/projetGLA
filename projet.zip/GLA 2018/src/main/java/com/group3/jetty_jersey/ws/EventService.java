package com.group3.jetty_jersey.ws;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.group3.jetty_jersey.dao.EventDao;

public class EventService {
	EventDao eventDao = new EventDao();

	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/delete/{id_event}")
	public String deleteMap(@PathParam("id_event") String id) {
		try {
			eventDao.delete(id);
			return "{\"result\":\"success\"}";
		} catch (Exception e) {
			return "{\"result\":\"error\"}";
		}
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/info/{id_event}")
	public String infoCarte(@PathParam("id_event") String id) throws Exception {
		return eventDao.getByID(id);
	}
}
