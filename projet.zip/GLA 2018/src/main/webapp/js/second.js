function mysubmit() {
	var usr = $('#nom').val();
	var mail = $('#mail').val();
	var last = $('#last').val();
	var first = $('#first').val();
	var gender = $('#gender').val();
	var daten = $('#daten').val();
	var pwd = $('#pwd').val();
	$.ajax({
		type : "put",
		url : '/ws/user/new',
		data : {
			'nom' : usr,
			'pwd' : pwd,
			'mail' : mail,
			'last' : last,
			'first' : first,
			'gender' : gender,
			'daten' : daten
		},
		dataType : "json",
		success : function(data) {
			if (data.result == 'success') {
				location.href = 'http://localhost:8020/test/home.html';
			} else {
				alert(data.result);
			}

		}
	})
}

$(function() {
	$("#button").click(function() {
		mysubmit();
	});
});

/*function mysubmit(url){
 var usr = $('#nom').val();
 var mail = $('#mail').val();
 var last = $('#last').val();
 var first = $('#first').val();
 var gender = $('#gender').val();
 var daten = $('#daten').val();
 var pwd = $('#pwd').val();.
 $.ajax({
 type:"put",
 url:'/ws/user/newuser',
 data:{'nom':usr,
 'pwd':pwd,
 'mail':mail,
 'last':last,
 'first':first,
 'gender':gender,
 'daten':daten}/*,
 dataType: "json",
 success:function (data) {
 if(data.result=='MCC'){
 var uri='http://localhost:8080/planning.html';
 sessionStorage.setItem("user",usr);
 sessionStorage.setItem("type",'mcc');

 location.href=uri;
 }else if(data.result=='MRO'){
 var uri='http://localhost:8080/MRO.html';
 sessionStorage.setItem("user",usr);
 sessionStorage.setItem("type",'mro');
 location.href=uri;
 }else{
 alert("please check account and password :(");
 }

 }
 })
 }

 $(function(){
 $("#button0").click(function(){
 mysubmit("ws/user/registration");
 });
 });*/