function mysubmit() {
	var usr = $('#usr').val();
	var pwd = $('#pwd').val();
	$.ajax({
		type : "post",
		url : '/ws/user/login',
		data : {
			'id' : usr,
			'pwd' : pwd
		},
		dataType : "json",
		success : function(data) {
			if (data.result == 'success') {
				var url = 'http://localhost:8020/test/home.html';
				sessionStorage.setItem("user", usr);
				location.href = url;
			} else {
				alert(data.result);
			}

		}
	})
}
