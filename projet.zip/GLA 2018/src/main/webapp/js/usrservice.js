function mysubmit() {
	var usr = $('#usr').val();
	var pwd = $('#pwd').val();
	$.ajax({
		type : "post",
		url : '/ws/user/login',
		data : {
			'id' : usr,
			'pwd' : pwd
		},
		dataType : "json",
		success : function(data) {
			if (data.result == 'success') {
				var url = 'http://localhost:8020/carte.html';
				sessionStorage.setItem("user", usr);
				location.href = url;
			} else {
				alert(data.result);
			}

		}
	})
}

function deconnexion() {
	
	$.ajax({
		type : "get",
		url : '/ws/user/deconnexion',
		dataType : "json",
		success : function(data) {
			if (data.result == 'success') {
				var url = 'http://localhost:8020/index.html';
				location.href = url;
			} else {
				alert(data.result);
			}

		}
	})
}

function registration() {
	var mail = $('#exampleInputEmail1').val();
	var usr = $('#validationDefaultUsername').val();
	var pwd = $('#InputPassword1').val();
	$.ajax({
		type : "put",
		url : '/ws/user/registration',
		data : {
			'usr' : usr,
			'pwd' : pwd,
			'mail' : mail
		},
		dataType : "json",
		success : function(data) {
			if (data.result == 'success') {
				location.href = 'http://localhost:8020/index.html';
			} else {
				alert(data.result);
			}

		}
	})
}
